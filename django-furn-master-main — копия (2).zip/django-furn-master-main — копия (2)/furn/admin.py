from django.contrib import admin
from .models import *

admin.site.register(MyUser)
admin.site.register(Carousel)
admin.site.register(Arrival)
admin.site.register(Blog)
admin.site.register(Product)
admin.site.register(Subscribe)
admin.site.register(Category)